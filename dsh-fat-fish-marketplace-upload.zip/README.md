# DSH Fat Fish - upload package

This folder contains everything needed to publish the plugin:

- `dsh-fat-fish/` - the public GitHub repository contents (package name `dsh-fat-fish`)
- `marketplace-entry/OWNER__dsh-fat-fish.yml` - catalog entry for the awesome-dsh-plugin registry
- `marketplace-entry/SUBMIT.md` - step-by-step submission checklist

## Before publishing

1. Create a public GitHub repository named `dsh-fat-fish`.
2. Replace `OWNER` in the marketplace YAML with your GitHub owner name, and rename the YAML file accordingly.
3. Confirm you have redistribution rights for `assets/default-avatar.webp` and `icon.webp`; see `dsh-fat-fish/NOTICE.md`.
4. Wait until the repository is at least 1 day old.
5. Submit the single YAML entry as a PR to awesome-dsh-plugin.

The package already declares the required `dsh.bundle` patch. No build step is needed. The code is MIT-licensed; the bundled character artwork is called out separately in `NOTICE.md`.
