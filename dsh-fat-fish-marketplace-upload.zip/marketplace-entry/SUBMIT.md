# Submit to the DSH Plugin Market

The market is curated through the [awesome-dsh-plugin](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin) GitHub registry. There is no in-app upload button.

## 1. Publish the repository

1. Create a **public** GitHub repository named `dsh-fat-fish`.
2. Upload the contents of `../dsh-fat-fish/` to the repository root. Do not upload the `marketplace-upload/` parent folder.
3. Confirm the repository contains `package.json`, `cordis.patch.yml`, `client.js`, `index.js`, `icon.webp`, `assets/default-avatar.webp`, and the locale files.
4. Add the GitHub topic `dsh-plugin` to the repository.
5. Confirm that you have redistribution rights for `assets/default-avatar.webp` and `icon.webp`; see `../dsh-fat-fish/NOTICE.md`. Replace them if you do not.

The marketplace requires the repository to be at least **1 day old**, so the submission cannot pass CI on the same day the repository is created.

## 2. Submit the catalog entry

1. Fork [awesome-dsh-plugin](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin).
2. Copy `OWNER__dsh-fat-fish.yml` to `data/plugins/<github-owner>__dsh-fat-fish.yml`.
3. In both the filename and the YAML, replace `OWNER` with the GitHub account that owns the repository.
4. Check that `url`, `name`, and `icon` point at the real repository.
5. Open a pull request adding exactly that one file. Do not edit the generated READMEs; the project regenerates them after merge.

`icon` must stay on GitHub hosting. If you rename the repository or default branch, update the raw URL.

## 3. Optional npm publication

Listing works from GitHub alone. If you also want download counts:

1. Add a `repository` field to `package.json` pointing at the published GitHub repository.
2. Publish the package as `dsh-fat-fish` (the name is currently unclaimed on npm).
3. Do not add an `npm:` key to the YAML; the registry maps it automatically.

## Before clicking submit

- [ ] Repository is public and at least 1 day old.
- [ ] `package.json` has `dsh.bundle.patch` and the patch file exists.
- [ ] `README.md`, `LICENSE`, and `NOTICE.md` are present.
- [ ] Character artwork rights are confirmed.
- [ ] The YAML entry has no placeholders.
- [ ] Only one plugin entry is added in the PR.
